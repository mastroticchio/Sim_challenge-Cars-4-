// ########################### Header Includes ###########################
#include "control/control_node.hpp"
#include <stdexcept>

namespace control {

/**********************************************************************************************************************
 *                                                   CONSTRUCTOR
 *********************************************************************************************************************/
ControlNode::ControlNode(const rclcpp::NodeOptions &node_options)
    : rclcpp::Node("control_control", node_options) {

  // ---------------- Parameters (values come from parameters.param.yaml; defaults = RacingController defaults)
  const ControllerParams d{};
  declare_parameter<double>("grip_scale", d.grip_scale);
  declare_parameter<double>("v_max", d.v_max);
  declare_parameter<double>("lat_omega", d.lat_omega);
  declare_parameter<double>("lat_zeta", d.lat_zeta);
  declare_parameter<double>("lat_ki", d.lat_ki);
  declare_parameter<double>("lat_int_limit", d.lat_int_limit);
  declare_parameter<double>("steer_limit", d.steer_limit);
  declare_parameter<double>("preview_time", d.preview_time);
  declare_parameter<double>("ff_lead_time", d.ff_lead_time);
  declare_parameter<double>("lon_kp", d.lon_kp);
  declare_parameter<double>("lon_ki", d.lon_ki);
  declare_parameter<double>("lon_int_limit", d.lon_int_limit);
  declare_parameter<double>("lon_preview_time", d.lon_preview_time);
  declare_parameter<double>("brake_bias_front", d.brake_bias_front);
  declare_parameter<double>("traction_scale", d.traction_scale);
  declare_parameter<double>("abs_scale", d.abs_scale);
  declare_parameter<double>("beta_cut", d.beta_cut);
  declare_parameter<double>("brake_front_max", d.brake_front_max);
  declare_parameter<double>("brake_rear_max", d.brake_rear_max);
  declare_parameter<double>("upshift_rpm", d.upshift_rpm);
  declare_parameter<double>("downshift_margin", d.downshift_margin);
  declare_parameter<double>("shift_cooldown", d.shift_cooldown);
  declare_parameter<bool>("debug_log", false);

  control_rate_hz_ = declare_parameter<double>("control_rate_hz", 100.0);

  // ---------------- Subscriber: best effort, only the newest state matters
  auto qos_best_effort = rclcpp::QoS(rclcpp::QoSInitialization(RMW_QOS_POLICY_HISTORY_KEEP_LAST, 1));
  qos_best_effort.best_effort();
  rclcpp::SubscriptionOptions options;
  options.callback_group = sub_callback_group_;
  sub_sim_out_ = create_subscription<custom_msgs::msg::SimOut>(
      "/sim_out", qos_best_effort, std::bind(&ControlNode::SimOutCbk, this, std::placeholders::_1), options);

  // ---------------- Publisher: reliable
  auto qos_reliable = rclcpp::QoS(rclcpp::QoSInitialization(RMW_QOS_POLICY_HISTORY_KEEP_LAST, 1));
  qos_reliable.reliable();
  pub_command_ = create_publisher<custom_msgs::msg::SimIn>("/sim_in", qos_reliable);

  // ---------------- Racing line: 3 rows (x, y, v), comma separated
  const std::string racing_line_file = ExpandHome(declare_parameter<std::string>("racing_line_file"));
  std::ifstream infile(racing_line_file);
  if (!infile.is_open()) {
    throw std::runtime_error("Cannot open racing line file: " + racing_line_file);
  }
  const std::vector<double> x = ReadRow(infile);
  const std::vector<double> y = ReadRow(infile);
  const std::vector<double> v = ReadRow(infile);

  ReadParameters();
  controller_.LoadTrack(x, y, v);  // also builds the speed profile with the current grip_scale
  last_grip_scale_ = controller_.params.grip_scale;
  last_v_max_ = controller_.params.v_max;
  RCLCPP_INFO(get_logger(), "Racing line loaded: %zu points, %.1f m.", x.size(), controller_.track_length());

  // ---------------- Timer
  const double period = 1.0 / control_rate_hz_;
  const rclcpp::Duration node_period(floor(period), floor((period - floor(period)) * 1e9));
  timer_ = rclcpp::create_timer(this, clock_, node_period, std::bind(&ControlNode::TimerLoop, this), timer_callback_group_);

  RCLCPP_INFO(get_logger(), "%s node started!", get_name());
}

ControlNode::~ControlNode() { RCLCPP_INFO(get_logger(), "%s destructor!", get_name()); }

/**********************************************************************************************************************
 *                                                    CALLBACKS
 *********************************************************************************************************************/
void ControlNode::SimOutCbk(const custom_msgs::msg::SimOut::SharedPtr msg) {
  std::lock_guard<std::mutex> lock(sim_out_msg_mutex_);
  sim_out_msg_ = msg;
}

void ControlNode::ReadParameters() {
  ControllerParams &p = controller_.params;
  p.grip_scale       = get_parameter("grip_scale").as_double();
  p.v_max            = get_parameter("v_max").as_double();
  p.lat_omega        = get_parameter("lat_omega").as_double();
  p.lat_zeta         = get_parameter("lat_zeta").as_double();
  p.lat_ki           = get_parameter("lat_ki").as_double();
  p.lat_int_limit    = get_parameter("lat_int_limit").as_double();
  p.steer_limit      = get_parameter("steer_limit").as_double();
  p.preview_time     = get_parameter("preview_time").as_double();
  p.ff_lead_time     = get_parameter("ff_lead_time").as_double();
  p.lon_kp           = get_parameter("lon_kp").as_double();
  p.lon_ki           = get_parameter("lon_ki").as_double();
  p.lon_int_limit    = get_parameter("lon_int_limit").as_double();
  p.lon_preview_time = get_parameter("lon_preview_time").as_double();
  p.brake_bias_front = get_parameter("brake_bias_front").as_double();
  p.traction_scale   = get_parameter("traction_scale").as_double();
  p.abs_scale        = get_parameter("abs_scale").as_double();
  p.beta_cut         = get_parameter("beta_cut").as_double();
  p.brake_front_max  = get_parameter("brake_front_max").as_double();
  p.brake_rear_max   = get_parameter("brake_rear_max").as_double();
  p.upshift_rpm      = get_parameter("upshift_rpm").as_double();
  p.downshift_margin = get_parameter("downshift_margin").as_double();
  p.shift_cooldown   = get_parameter("shift_cooldown").as_double();
}

/**********************************************************************************************************************
 *                                                    MAIN LOOP
 *********************************************************************************************************************/
void ControlNode::TimerLoop() {
  custom_msgs::msg::SimOut::SharedPtr msg;
  {
    std::lock_guard<std::mutex> lock(sim_out_msg_mutex_);
    msg = sim_out_msg_;
  }
  if (!msg) {
    return;  // no state from the simulator yet
  }

  // Live tuning: gains are re-read every cycle; the speed profile is rebuilt only if its inputs change
  ReadParameters();
  if (controller_.params.grip_scale != last_grip_scale_ || controller_.params.v_max != last_v_max_) {
    controller_.BuildSpeedProfile();
    last_grip_scale_ = controller_.params.grip_scale;
    last_v_max_ = controller_.params.v_max;
    RCLCPP_INFO(get_logger(), "Speed profile rebuilt (grip_scale %.2f, v_max %.1f).", last_grip_scale_, last_v_max_);
  }

  VehicleState st;
  st.x          = msg->x;
  st.y          = msg->y;
  st.heading    = msg->heading;
  st.vx         = msg->vx;
  st.vy         = msg->vy;
  st.yaw_rate   = msg->omegaz;
  st.engine_rpm = msg->engine_rpm;
  st.gear       = static_cast<int>(std::lround(msg->gear_data));

  const Command cmd = controller_.Step(st, 1.0 / control_rate_hz_);

  custom_msgs::msg::SimIn out{};
  out.steering_cmd          = cmd.steer;
  out.accelerator_pedal_cmd = cmd.pedal;
  out.gear_cmd              = static_cast<double>(cmd.gear);
  // NOTE: the simulator multiplies these fields by 1e5 (see E3 and the plant code), so they are in bar
  out.brake_fl_cmd          = cmd.brake_front;
  out.brake_fr_cmd          = cmd.brake_front;
  out.brake_rl_cmd          = cmd.brake_rear;
  out.brake_rr_cmd          = cmd.brake_rear;
  out.push_to_pass_cmd      = 0.0;
  pub_command_->publish(out);

  if (get_parameter("debug_log").as_bool() && (++log_counter_ % 20 == 0)) {
    const Diagnostics &dg = controller_.diag();
    RCLCPP_INFO(get_logger(), "s %.0f  e_y %+.2f  e_psi %+.3f  v %.1f/%.1f  steer %+.3f  pedal %.2f  brake %.0f/%.0f bar  gear %d",
                dg.s, dg.e_y, dg.e_psi, st.vx, dg.v_ref, cmd.steer, cmd.pedal, cmd.brake_front, cmd.brake_rear, cmd.gear);
  }
}

} // namespace control

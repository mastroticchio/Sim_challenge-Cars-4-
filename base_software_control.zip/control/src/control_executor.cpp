// ####################### Standard includes ############################
#include <rclcpp/rclcpp.hpp>

// ####################### Packages includes ############################
#include "control/control_node.hpp"

int main(int argc, char *argv[])
{
    // Force flush of the stdout buffer.
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

    // Initialize global resources
    rclcpp::init(argc, argv);

    rclcpp::NodeOptions options;

    // Create and spin the control node
    auto control_node = std::make_shared<control::ControlNode>(options);
    rclcpp::spin(control_node);
    rclcpp::shutdown();
    return 0;
}

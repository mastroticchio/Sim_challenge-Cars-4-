#pragma once
// ######################### Standard Libraries ###########################
#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace control {

/**
 * Racing controller: PID-based path and speed tracking on the optimised racing line.
 *
 * It has no ROS dependency, so the same code runs inside the ROS 2 node and inside the
 * offline test harness that drives the simulator plant directly.
 *
 *   lateral      : curvature feedforward  + PID on the lateral error (derivative = analytic
 *                  rate of the lateral error, no numerical derivative), with 60 ms delay preview
 *   longitudinal : feedforward from the speed profile + PID on the speed error -> wheel force
 *                  -> inverse engine map (pedal) or brake pressure (bar)
 *   gearshift    : per-gear thresholds derived from the gear ratios (upshift near the limiter)
 *
 * All vehicle numbers come from the identification (dispensa, 11/11/2026).
 */

// ---------------------------------------------------------------------------------------------
// Tunable parameters (can be changed at run time through ROS parameters)
// ---------------------------------------------------------------------------------------------
struct ControllerParams {
  // Speed profile
  double grip_scale       = 0.85;  // [-]   fraction of the identified grip used by the profile
  double v_max            = 80.0;  // [m/s] absolute speed cap
  // Lateral PID (designed on the error dynamics  e'' + 2 zeta w e' + w^2 e = 0)
  double lat_omega        = 3.5;   // [rad/s] closed-loop bandwidth of the lateral error
  double lat_zeta         = 0.9;   // [-]     damping
  double lat_ki           = 0.15;  // [1/s^3] integral on the lateral error (scaled like kp)
  double lat_int_limit    = 0.02;  // [rad]   max steering from the integral term
  double steer_limit      = 0.32;  // [rad]   the simulator saturates the wheel angle at ~0.321 rad
  double preview_time     = 0.08;  // [s]     actuator delay compensation (60 ms + half a period)
  double ff_lead_time     = 0.20;  // [s]     curvature read slightly ahead of the predicted pose
  // Longitudinal PID (on speed, output = acceleration)
  double lon_kp           = 1.2;   // [1/s]
  double lon_ki           = 0.3;   // [1/s^2]
  double lon_int_limit    = 1.5;   // [m/s^2]
  double lon_preview_time = 0.25;  // [s] speed reference read ahead (pedal/brake delay)
  double brake_bias_front = 0.62;  // [-]
  double traction_scale   = 0.85;
  double abs_scale        = 0.85;  // [-] share of the tyre grip given to braking (wheel-lock margin)  // [-] share of the rear tyre grip given to traction
  double beta_cut         = 0.08;  // [rad] sideslip above which the throttle is cut
  double brake_front_max  = 90.0;  // [bar] per wheel
  double brake_rear_max   = 50.0;  // [bar] per wheel
  // Gearshift
  double upshift_rpm      = 7800.0;  // [rpm]
  double downshift_margin = 400.0;   // [rpm] below the limiter for the next lower gear
  double shift_cooldown   = 0.4;     // [s]   sim time between two shifts
};

// ---------------------------------------------------------------------------------------------
// Identified vehicle model (constants)
// ---------------------------------------------------------------------------------------------
struct VehicleModel {
  double m    = 720.0;               // [kg]
  double a    = 1.760, b = 1.355;    // [m]  CoG to front / rear axle
  double L    = 3.115;               // [m]
  double h    = 0.358;               // [m]
  double rho  = 1.225, CdA = 1.194, ClfA = 1.832, ClrA = 1.948;
  double c2   = 0.7313;              // [N s^2/m^2] = 0.5 rho CdA (E1)
  double Rw   = 0.310;               // [m]
  double T_eb = -53.5;               // [Nm] engine torque at pedal 0 (E1)
  double K_brake = 1.36e-4;          // [Nm/Pa] per wheel (E3)
  std::array<double, 6> G{8.689, 6.442, 4.973, 4.005, 3.355, 2.919};  // total ratios (E2, E7)
  // Tyres, Pacejka peak: mu = mu0 (1 + mu1 (Fz - Fz0)/Fz0)  (E5)
  double mu0_f = 1.41, mu1_f = -0.25;
  double mu0_r = 1.58, mu1_r = -0.14;
  double g = 9.81;
};

struct VehicleState {
  double x = 0, y = 0, heading = 0;  // ENU, CoG
  double vx = 0, vy = 0, yaw_rate = 0;
  double engine_rpm = 0;
  int gear = 1;
};

struct Command {
  double steer = 0;        // [rad]
  double pedal = 0;        // [0-1]
  double brake_front = 0;  // [bar] per wheel (the simulator multiplies the command by 1e5)
  double brake_rear  = 0;  // [bar] per wheel
  int gear = 1;
};

// Diagnostics, useful for logging and tuning
struct Diagnostics {
  double s = 0, e_y = 0, e_psi = 0, kappa = 0, v_ref = 0, a_cmd = 0, dt = 0;
  double steer_ff = 0, steer_fb = 0;
};

class RacingController {
 public:
  RacingController() = default;

  /// Loads the racing line (3 rows: x, y, v) and builds geometry and speed profile.
  void LoadTrack(const std::vector<double>& x, const std::vector<double>& y, const std::vector<double>& v);
  /// Rebuilds the speed profile (call after changing grip_scale or v_max).
  void BuildSpeedProfile();

  /// One control step. dt_hint is the nominal period; the true simulated dt is estimated from ds/v.
  Command Step(const VehicleState& st, double dt_hint);

  ControllerParams params;
  VehicleModel veh;
  const Diagnostics& diag() const { return diag_; }
  const std::vector<double>& profile() const { return v_prof_; }
  double track_length() const { return length_; }

 private:
  // Track, closed loop, resampled with uniform spacing
  std::vector<double> x_, y_, s_, psi_, kappa_, v_csv_, v_prof_;
  double ds_ = 0.5, length_ = 0;
  std::size_t idx_ = 0;          // last projection index (local search)
  bool localised_ = false;

  // Controller states
  double int_lat_ = 0, int_lon_ = 0;
  double since_shift_ = 1e3;
  int gear_cmd_ = 0;            // gear commanded by the controller (0 = not initialised)
  bool have_prev_ = false;
  double prev_x_ = 0, prev_y_ = 0;
  Diagnostics diag_;

  // Helpers
  std::size_t Wrap(long i) const;
  double Interp(const std::vector<double>& f, double s) const;
  void Project(double x, double y, double& s, double& e_y, double& psi_ref);
  double AyMax(double v) const;               // lateral limit (front axle) [m/s^2]
  double AxBrakeMax(double v) const;          // braking limit [m/s^2] (positive)
  double AxDriveMax(double v) const;          // traction / power limit [m/s^2]
  double EngineTorque(double pedal, double rpm) const;
  double PedalForTorque(double T, double rpm) const;
  int    SelectGear(const VehicleState& st, double dt);
};

}  // namespace control

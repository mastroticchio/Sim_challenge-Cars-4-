#pragma once

// ######################### Standard Libraries ###########################
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

namespace control {

// Output of the lateral controller.
struct LateralCmd {
  double steer_angle = 0.0; // [rad] Front wheel steering angle command
};

// Output of the longitudinal controller. Throttle and brakes are never both non zero.
struct LongitudinalCmd {
  double throttle          = 0.0; // [0-1] Accelerator pedal command
  double brake_pressure_fl = 0.0; // [Pa]  Front left brake pressure command
  double brake_pressure_fr = 0.0; // [Pa]  Front right brake pressure command
  double brake_pressure_rl = 0.0; // [Pa]  Rear left brake pressure command
  double brake_pressure_rr = 0.0; // [Pa]  Rear right brake pressure command
  std::int64_t gear        = 0;   // [#]   Gear command
};

// Vehicle data that never changes at run time, loaded once from constants.param.yaml.
struct VehicleConstants {
  double brake_bias_front   = 0.0; // [-]  Share of the braking demand sent to the front axle
  double max_brake_pressure = 0.0; // [Pa] Maximum pressure command
  int64_t min_gear     = 0;   // [#]  Lowest selectable gear
  int64_t max_gear     = 0;   // [#]  Highest selectable gear
};

// Reads one line of the csv and returns its comma separated values.
///        Each call consumes the next line, so the caller decides which field each row holds.
inline std::vector<double> ReadRow(std::ifstream &t_infile) {
  std::vector<double> values;
  std::string line;
  std::getline(t_infile, line);

  std::istringstream iss(line);
  std::string cell;
  while (std::getline(iss, cell, ',')) {
    values.push_back(std::stod(cell));
  }

  return values;
}

// Replaces a leading "$HOME" in the path with the HOME environment variable.
///        ROS 2 parameter files do not expand environment variables on their own.
inline std::string ExpandHome(const std::string &t_path) {
  const std::string prefix = "$HOME";
  const char *home         = std::getenv("HOME");
  if (home == nullptr || t_path.rfind(prefix, 0) != 0) {
    return t_path;
  }

  return std::string(home) + t_path.substr(prefix.size());
}

// Reference line to follow. The four vectors are parallel: index i describes the same point.
struct Track {
  std::vector<double> x;  // [m]   x coordinate (ENU frame)
  std::vector<double> y;  // [m]   y coordinate (ENU frame)
  std::vector<double> vx; // [m/s] Reference longitudinal speed

  /// @brief Index of the reference point closest to (t_x, t_y).
  ///        Brute force scan over the whole line: no assumption is made on where the vehicle was
  ///        at the previous cycle, at the cost of a full pass per call.
  std::size_t FindClosestPoint(double t_x, double t_y) const {
    std::size_t closest_idx = 0;
    double min_dist_sq      = std::numeric_limits<double>::max();

    // Squared distance: comparing it is equivalent to comparing the distance, and saves the sqrt.
    for (std::size_t i = 0; i < x.size(); i++) {
      const double dist_sq = (x.at(i) - t_x) * (x.at(i) - t_x) + (y.at(i) - t_y) * (y.at(i) - t_y);
      if (dist_sq < min_dist_sq) {
        min_dist_sq = dist_sq;
        closest_idx = i;
      }
    }

    return closest_idx;
  }
};

} // namespace control

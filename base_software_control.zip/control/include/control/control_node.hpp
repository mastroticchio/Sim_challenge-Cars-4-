#pragma once

// ######################### Standard Libraries ###########################
#include <rclcpp/rclcpp.hpp>
#include <chrono>
#include <mutex>
#include <string>

// ############################ Local Headers #############################
#include "datatypes.hpp"
#include "racing_controller.hpp"

// ############################### Messages ###############################
#include "custom_msgs/msg/sim_in.hpp"
#include "custom_msgs/msg/sim_out.hpp"

namespace control {

/**
 * @brief ROS 2 wrapper of the RacingController.
 *
 * Same structure as the baseline: the subscriber stores the latest /sim_out message, a timer at
 * control_rate_hz runs the controller and publishes /sim_in. All the control logic lives in
 * RacingController (racing_controller.hpp/.cpp), which has no ROS dependency.
 */
class ControlNode : public rclcpp::Node {
private:
    // Subscribers / publishers / timer
    rclcpp::Subscription<custom_msgs::msg::SimOut>::SharedPtr sub_sim_out_{nullptr};
    rclcpp::Publisher<custom_msgs::msg::SimIn>::SharedPtr pub_command_{nullptr};
    rclcpp::TimerBase::SharedPtr timer_{nullptr};

    rclcpp::CallbackGroup::SharedPtr sub_callback_group_ =
        create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);
    rclcpp::CallbackGroup::SharedPtr timer_callback_group_ =
        create_callback_group(rclcpp::CallbackGroupType::MutuallyExclusive);

    // Latest simulator state
    void SimOutCbk(const custom_msgs::msg::SimOut::SharedPtr msg);
    custom_msgs::msg::SimOut::SharedPtr sim_out_msg_{nullptr};
    std::mutex sim_out_msg_mutex_;

    rclcpp::Clock::SharedPtr clock_ = get_clock();

    // Controller
    RacingController controller_;
    double control_rate_hz_{100.0};
    double last_grip_scale_{-1.0};
    double last_v_max_{-1.0};
    int log_counter_{0};

    void TimerLoop();
    void ReadParameters();   // copies the ROS parameters into controller_.params (live tuning)

public:
    explicit ControlNode(const rclcpp::NodeOptions &node_options);
    ~ControlNode() override;
};

} // namespace control

import os

from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    # Define LaunchDescription variable
    ld = LaunchDescription()

    control_node_consts = os.path.join(
        get_package_share_directory('base_software_control'),
        'param',
        'constants.param.yaml'
    )

    control_node_params = os.path.join(
        get_package_share_directory('base_software_control'),
        'param',
        'parameters.param.yaml'
    )

    control_node = Node(
        name="base_software_control",
        package='base_software_control',
        namespace='polimove',
        executable='control_exe',
        output='screen',
        parameters=[
            control_node_consts,
            control_node_params
        ],
        respawn=True,
        respawn_delay=0.5
    )

    ld.add_action(control_node)

    return ld
